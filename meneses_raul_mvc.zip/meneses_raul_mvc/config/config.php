<?php
	
	define("CONTROLADOR_PRINCIPAL", "Clientes");
	define("ACCION_PRINCIPAL", "index");
	
?>